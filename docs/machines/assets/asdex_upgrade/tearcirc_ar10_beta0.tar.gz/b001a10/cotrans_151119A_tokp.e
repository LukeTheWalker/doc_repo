##################################################################
#!/bin/sh
##################################################################
#
# A simple submit script for starting mpi jobs on two nodes 
#
# @author Rechenzentrum der MPG, Garching
# @author Germany
#
##################################################################
#
# SGE options:
#
# Change to the current working directory upon starting of the job
#$ -cwd
#
# production queue
# -P tokp
# develop queue
#$ -P debug
#
# join the error and standard output streams
#$ -j y
#
#$ -pe impi_hydra  16      
#
# set the required cpu time of your job h_cpu=hh:mm:ss
#$ -l h_rt=02:00:00
#
# don't flood myself with e-mail
#$ -m e
#
# this is my e-mail address
#$ -M ers@ipp.mpg.de
#
# notify me about pending SIG_STOP and SIG_KILL
#$ -notify
#
# name of the job
#$ -N COTRANS
#
# end of SGE stuff
###################################################################
# now execute my job:

module load intel/14.0
module load impi/4.1.3
module load perflib
module load mkl/11.1
module load nag_flib/intel/mk24

mpirun -perhost 16 -l -np 16 /pfs/u/ers/COSYMA/COTRANS_151119A_TOKP_xHost < ./in_m0

date

# end of job script
###################################################################
